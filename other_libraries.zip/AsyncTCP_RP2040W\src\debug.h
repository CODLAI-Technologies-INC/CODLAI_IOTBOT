#ifndef DEBUG_H_
#define DEBUG_H_

void panic();

#endif
